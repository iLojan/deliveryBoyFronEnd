<template lang="">
  <div style="font-size: 14px;">
    <div :style="divStyle" id="divpdf">
      <div :style="pageStyle" id="pdfpreview">
        <div :style="headerStyle" id="resume6">
          <div :style="bodyStyle1">
            <div style=" padding-left: 15px; padding-right: 15px" :style="bodyStyle1">
              <div class="" style="width: 100%; text-align: left;color:#243545">
                <div>
                  <p :style="nameStyle" style="display: block !important">
                    John Jenkins
                  </p>
                </div>

              </div>

              <div style="
                            text-align: center;
                            line-height: 21px;
                          ">
                <p style="
                              font-weight: 500;
                              color: #243545;
                              font-size: 14px;
                              text-align: center;
                              margin-bottom: 4px;
                            ">
                  15Cook Lane,Scarsdale,NY 107050 / C:0758907249 / Jone@gmail.com

                </p>
              </div>
            </div>
          </div>
        </div>
        <div class="" :style="bodyStyle">
          <div class="" style="color: black;">Software Engineer</div>
          <div class="" :style="profileStyle">I am a highly competent IT professional with a proven track record in
            designing websites,graphic designs ,
            networking and managing databases. I have strong technical skills as well as excellent interpersonal skills,
            enabling me to
            interact with a wide range of clients. I am eager to be challenged in
            order to grow and further improve my IT skills. My greatest passion is in life is using my technical
            know-how to benefit kkl.</div>
        </div>
        <!-- Experience -->
        <div class="" :style="bodyStyle">
        
          <div class="" :style="sectionTitleStyle">
            Experience
          </div>
          <!-- 1 -->
          <div class="" style="padding-bottom: 14px;">
            <div class="" style="display: flex;">
              <div class="" style="width: 70%;">
                <div class="" style="padding-bottom: 5px;color:#000">ABC Lanka(PVT) Ltd</div>
                <div class="" style="font-weight: 600;font-size: 13px;color: black;">Associate Software Engineer(Colombo
                  ,
                  Sri Lanka)</div>
              </div>
              <div class="" style="width: 30%;text-align: right;">
                <div class="">08/2017 - 05/2021</div>
              </div>
            </div>
            <div class="c" :style="paragraph">
              This is currently blocking Dev and QA Environments.
              I am a highly competent IT professional with a proven track record in designing websites,graphic designs
              ,networking and managing databases. I have strong technical skills as well as excellent interpersonal
              skills, enabling me to interact with a wide range of clients. I am eager to be challenged in order to grow
              and further improve my IT skills. My greatest passion is in life is using my technical know-how to benefit
              Worked as web developer and Graphics designer in Red stone (PVT)LTD since February (2016) to 2017
            </div>
          </div>
          <!-- 2 -->
          <div class="" style="padding-bottom: 14px;">
            <div class="" style="display: flex;">
              <div class="" style="width: 70%;">
                <div class="" style="padding-bottom: 3px;">ZXC Corners Lanka(PVT) Ltd</div>
                <div class="" style="font-weight: 600;font-size: 13px;color: black;">Associate Software Engineer(Colombo
                  ,
                  Sri Lanka)</div>
              </div>
              <div class="" style="width: 30%;text-align: right;">
                <div class="">08/2017 - 05/2021</div>
              </div>
            </div>
            <div class="c" :style="paragraph">
              This is currently blocking Dev and QA Environments.
              I am a highly competent IT professional with a proven track record in designing websites,graphic designs
              ,networking and managing databases. I have strong technical skills as well as excellent interpersonal
              skills, enabling me to interact with a wide range of clients. I am eager to be challenged in order to grow
              and further improve my IT skills. My greatest passion is in life is using my technical know-how to benefit
              Worked as web developer and Graphics designer in Red stone (PVT)LTD since February (2016) to 2017
            </div>
          </div>
        </div>
            <!-- Education -->
        <div class="" :style="bodyStyle">
        
          <div class="" :style="sectionTitleStyle">
            Education
          </div>
          <!-- 1 -->
          <div class="" style="padding-bottom: 14px;">
            <div class="" style="display: flex;">
              <div class="" style="width: 70%;">
                <div class="" style="padding-bottom: 5px;color:#000">Ranabima Royal Coleege , BCA<span> <strong>GPA</strong> 83.3  </span></div>
                <div class="" style="font-weight: 600;font-size: 13px;color: black;">Bachelor of Business Management (Colombo , Sri lanka)</div>
              </div>
              <div class="" style="width: 30%;text-align: right;">
                <div class="">08/2017 - 05/2021</div>
              </div>
            </div>
            <div class="c" :style="paragraph">
              This is currently blocking Dev and QA Environments.
              I am a highly competent IT professional with a proven track record in designing websites,graphic designs
              ,networking and managing databases. I have strong technical skills as well as excellent interpersonal
              skills, enabling me to interact with a wide range of clients. I am eager to be challenged in order to grow
              and further improve my IT skills. My greatest passion is in life is using my technical know-how to benefit
              Worked as web developer and Graphics designer in Red stone (PVT)LTD since February (2016) to 2017
            </div>
          </div>
          <!-- 2 -->
          <div class="" style="padding-bottom: 14px;">
            <div class="" style="display: flex;">
              <div class="" style="width: 70%;">
                <div class="" style="padding-bottom: 5px;color:#000">Ranabima Royal Coleege , BCA<span> <strong>GPA</strong> 83.3  </span></div>
                <div class="" style="font-weight: 600;font-size: 13px;color: black;">Bachelor of Business Management (Colombo , Sri lanka)</div>
              </div>
              <div class="" style="width: 30%;text-align: right;">
                <div class="">08/2017 - 05/2021</div>
              </div>
            </div>
            <div class="c" :style="paragraph">
              This is currently blocking Dev and QA Environments.
              I am a highly competent IT professional with a proven track record in designing websites,graphic designs
              ,networking and managing databases. I have strong technical skills as well as excellent interpersonal
              skills, enabling me to interact with a wide range of clients. I am eager to be challenged in order to grow
              and further improve my IT skills. My greatest passion is in life is using my technical know-how to benefit
              Worked as web developer and Graphics designer in Red stone (PVT)LTD since February (2016) to 2017
            </div>
          </div>
        </div>
        <!--  -->
             <!-- Languages -->
             <div class="" :style="bodyStyle">
        
              <div class="" :style="sectionTitleStyle">
                Languages
              </div>
              <!-- 1 -->
              <div class="" style="padding-bottom: 14px;">
                <div class="" style="display: flex;">
                  <div class="" style="width: 100%;">
                    <div class="" style="padding-bottom: 5px;color:#000">English</div>
                  </div>
                </div>
                <div class="c" :style="paragraph">
                  This is currently blocking Dev and QA Environments.
                  I am a highly competent IT professional with a proven track record in designing websites,graphic designs
                  ,networking and managing databases. I have strong technical skills as well as excellent interpersonal
                  skills, enabling me to interact with a wide range of clients. I am eager to be challenged in order to grow
                  and further improve my IT skills. My greatest passion is in life is using my technical know-how to benefit
                  Worked as web developer and Graphics designer in Red stone (PVT)LTD since February (2016) to 2017
                </div>
              </div>
              <!-- 2 -->
              <div class="" style="padding-bottom: 14px;">
                <div class="" style="display: flex;">
                  <div class="" style="width: 70%;">
                    <div class="" style="padding-bottom: 5px;color:#000">Tamil</div>
                  </div>
                </div>
              </div>
            </div>
            <!--  -->
               <!-- Certificates -->
        <div class="" :style="bodyStyle">
        
          <div class="" :style="sectionTitleStyle">
            Certificates
          </div>
          <!-- 1 -->
          <div class="" style="padding-bottom: 14px;">
            <div class="" style="display: flex;">
              <div class="" style="width: 70%;">
                <div class="" style="padding-bottom: 5px;color:#000">ICT NVQ Level 5(diploma)<span> <strong>GPA</strong> 83.3  </span></div>
                <div class="" style="font-weight: 600;font-size: 13px;color: black;">National Vocational Training Institute-vantharumoolai VTA-Batticaloa (Colombo , Sri lanka)</div>
                <div class="" style="display: block;">(https://NVQ .com)</div>
              </div>
              <div class="" style="width: 30%;text-align: right;">
                <div class="">08/2017 - 05/2021</div>
              </div>
            </div>
            <div class="c" :style="paragraph">
              This is currently blocking Dev and QA Environments.
              I am a highly competent IT professional with a proven track record in designing websites,graphic designs
              ,networking and managing databases. I have strong technical skills as well as excellent interpersonal
              skills, enabling me to interact with a wide range of clients. I am eager to be challenged in order to grow
              and further improve my IT skills. My greatest passion is in life is using my technical know-how to benefit
              Worked as web developer and Graphics designer in Red stone (PVT)LTD since February (2016) to 2017
            </div>
          </div>
        </div>
        <!--  -->
            <!-- Interests -->
            <div class="" :style="bodyStyle">
        
              <div class="" :style="sectionTitleStyle">
                Interests
              </div>
              <!-- 1 -->
              <div class="" style="padding-bottom: 14px;">
                <div class="" style="display: flex;">
                  <div class="" style="width: 100%;">
                    <div class="" style="padding-bottom: 5px;color:#000">sparkle
                      BTEC. WEB TECHNOLOGY & MULTIMED</div>
                  </div>
                </div>
                <div class="c" :style="paragraph">
                  This is currently blocking Dev and QA Environments.
                  I am a highly competent IT professional with a proven track record in designing websites,graphic designs
                  ,networking and managing databases. I have strong technical skills as well as excellent interpersonal
                  skills, enabling me to interact with a wide range of clients. I am eager to be challenged in order to grow
                  and further improve my IT skills. My greatest passion is in life is using my technical know-how to benefit
                  Worked as web developer and Graphics designer in Red stone (PVT)LTD since February (2016) to 2017
                </div>
              </div>
             
            </div>
            <!--  -->
            <!-- Projects -->
            <div class="" :style="bodyStyle">
            
              <div class="" :style="sectionTitleStyle">
                Projects
              </div>
              <!-- 1 -->
              <div class="" style="padding-bottom: 14px;">
                <div class="" style="display: flex;">
                  <div class="" style="width: 70%;">
                    <div class="" style="padding-bottom: 5px;color:#000">ICT NVQ Level 5(diploma)<span> <strong>GPA</strong> 83.3 </span>
                    </div>
                    <div class="" style="font-weight: 600;font-size: 13px;color: black;">National Vocational Training
                      Institute-vantharumoolai VTA-Batticaloa (Colombo , Sri lanka)</div>
                    <div class="" style="display: block;">https://project.com</div>
                  </div>
                  <div class="" style="width: 30%;text-align: right;">
                    <div class="">08/2017 - 05/2021</div>
                  </div>
                </div>
                <div class="c" :style="paragraph">
                  This is currently blocking Dev and QA Environments.
                  I am a highly competent IT professional with a proven track record in designing websites,graphic designs
                  ,networking and managing databases. I have strong technical skills as well as excellent interpersonal
                  skills, enabling me to interact with a wide range of clients. I am eager to be challenged in order to grow
                  and further improve my IT skills. My greatest passion is in life is using my technical know-how to benefit
                  Worked as web developer and Graphics designer in Red stone (PVT)LTD since February (2016) to 2017
                </div>
              </div>
            </div>
            <!--  -->
            <!-- Courses -->
            <div class="" :style="bodyStyle">
            
              <div class="" :style="sectionTitleStyle">
                Courses
              </div>
              <!-- 1 -->
              <div class="" style="padding-bottom: 14px;">
                <div class="" style="display: flex;">
                  <div class="" style="width: 70%;">
                    <div class="" style="padding-bottom: 5px;color:#000">ICT NVQ Level 5(diploma)<span> <strong>GPA</strong> 83.3 </span>
                    </div>
                    <div class="" style="font-weight: 600;font-size: 13px;color: black;">National Vocational Training
                      Institute-vantharumoolai VTA-Batticaloa (Colombo , Sri lanka)</div>
                    <div class="" style="display: block;">https://project.com</div>
                  </div>
                  <div class="" style="width: 30%;text-align: right;">
                    <div class="">08/2017 - 05/2021</div>
                  </div>
                </div>
                <div class="c" :style="paragraph">
                  This is currently blocking Dev and QA Environments.
                  I am a highly competent IT professional with a proven track record in designing websites,graphic designs
                  ,networking and managing databases. I have strong technical skills as well as excellent interpersonal
                  skills, enabling me to interact with a wide range of clients. I am eager to be challenged in order to grow
                  and further improve my IT skills. My greatest passion is in life is using my technical know-how to benefit
                  Worked as web developer and Graphics designer in Red stone (PVT)LTD since February (2016) to 2017
                </div>
              </div>
            </div>
            <!--  -->
              <!-- Awards -->
              <div class="" :style="bodyStyle">
            
                <div class="" :style="sectionTitleStyle">
                  Awards
                </div>
                <!-- 1 -->
                <div class="" style="padding-bottom: 14px;">
                  <div class="" style="display: flex;">
                    <div class="" style="width: 70%;">
                      <div class="" style="padding-bottom: 5px;color:#000"> Enter award name </div>
                      <div class="" style="font-weight: 600;font-size: 13px;color: black;">Enter Issuer</div>
                      <div class="" style="display: block;">https://award.com</div>
                    </div>
                    <div class="" style="width: 30%;text-align: right;">
                      <div class="">08/2017 </div>
                    </div>
                  </div>
                  <div class="c" :style="paragraph">
                    This is currently blocking Dev and QA Environments.
                    I am a highly competent IT professional with a proven track record in designing websites,graphic designs
                    ,networking and managing databases. I have strong technical skills as well as excellent interpersonal
                    skills, enabling me to interact with a wide range of clients. I am eager to be challenged in order to grow
                    and further improve my IT skills. My greatest passion is in life is using my technical know-how to benefit
                    Worked as web developer and Graphics designer in Red stone (PVT)LTD since February (2016) to 2017
                  </div>
                </div>
              </div>
              <!--  -->
                <!-- Skill -->
                <div class="" :style="bodyStyle">
            
                  <div class="" :style="sectionTitleStyle">
                    Skills
                  </div>
                  <!-- 1 -->
                  <div class="" style="padding-bottom: 14px;">
                    <div class="" style="display: flex;">
                      <div class="" style="width: 100%;">
                        <div class="" style="padding-bottom: 5px;color:#000"> Skill Catogory Name </div>
                      </div>
                    </div>
                    <div class="c">
                      <div class="" style="display: flex; justify-content: space-between; padding-top: 5px;">
                        <div class="">Skill Name</div>
                        <div class="" style="text-align: right;">Elementary</div>
                      </div>
                      <div class="" style="display: flex; justify-content: space-between; padding-top: 5px;">
                        <div class="">Skill Name 1</div>
                        <div class="" style="text-align: right;">Elementary</div>
                      </div>
                    </div>
                  </div>
                </div>
                <!--  -->
                    <!-- References -->
              <div class="" :style="bodyStyle">
            
                <div class="" :style="sectionTitleStyle">
                  References
                </div>
                <!-- 1 -->
                <div class="" style="padding-bottom: 14px;">
                  <div class="" style="display: flex;">
                    <div class="" style="width: 50%;">
                      <div class="" style="padding-bottom: 5px;color:#000"> <strong>MR.M.M.M.Sukry</strong>  Senior ICT Instuctor, National Vocational Training Institute-vantharumoolai VTA-Batticaloa </div>
                      <div class="" style="font-weight: 600;font-size: 13px;color: black;">Enter Issuer</div>
                      <div class="" style="display: block;">https://award.com</div>
                    </div>
                    <div class="" style="width: 50%;text-align: right;">
                      <div class="" style="display: flex;text-align: right;">
                        <div class="">E-mail</div>
                        <div class="">sukry1021@gmail.com</div>
                      </div>
                      <div class="" style="display: flex;text-align: right;">
                        <div class="">Phone</div>
                        <div class="">758907689</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!--  -->
      </div>
    </div>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        divStyle: {
          width: '794px',
          background: 'white',
          display: 'block',
          boxShadow: '0 0 0.5cm rgb(0 0 0 / 50%)',
          padding: '10px'
        },
        paragraph:{
       fontSize:"12px",
       marginTop:"3px"
        },
        pageStyle: {
          fontFamily: "'Montserrat', sans-serif",
          lineHeight: '1.15'
        },
        headerStyle: {
          paddingTop: '40px',
          marginBottom: '20px',
          color: '#243545',
          textAlign: 'center',
          borderBottom: "solid 4px #000"
        },
        profileStyle: {
          fontSize:"12px",
       marginTop:"3px",
          color: '#000',
          fontWeight: '600'
        },
        bodyStyle: {
          paddingLeft: '30px',
          paddingRight: '30px',
          paddingBottom: '20px',
          fontSize: '12'
        },
        nameStyle: {
          fontSize: '22px',
          color: '#243545',
          textTransform: 'capitalize',
          textAlign: 'center',
          marginBottom: '0px',
          marginTop: '0px',
          fontWeight: 500
        },
        sectionTitleStyle: {
          fontSize: '14px',
          // fontWeight: 700,
          color: '#000',
          textTransform: "UPPERCASE",
          borderBottom: "solid 4px #000",
          textAlign: "center",
          padding: "5px",
          paddingBottom: '3px',
          marginBottom: '24px'

        },
      }
    },
  }
</script>
<style lang="">

</style>